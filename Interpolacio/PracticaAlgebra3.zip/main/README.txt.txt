MEMBRES DEL GRUP: Roger Alamañac, Elena Ramón

La càmera es canvia amb la lletra C. Es pot desplaçar la càmera amb les fletxes amun avall, esquerra i dreta.